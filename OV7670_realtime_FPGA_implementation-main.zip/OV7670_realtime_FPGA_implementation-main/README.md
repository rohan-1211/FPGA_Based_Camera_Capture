ece 385 final project shiz
